<?php

/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 12.09.2015
 * Time: 15:21
 */
class UserLoginRegisterChecker {

}