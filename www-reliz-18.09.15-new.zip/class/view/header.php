<?php
//echo __FILE__;
//$sessionObj = new SessionSystemSetting();
//TODO: этот блок над сайтом (заголовки и тд!)
// $Obj = new Devoleper();
// TODO: подключить Develeper для вывода системных ошибо

