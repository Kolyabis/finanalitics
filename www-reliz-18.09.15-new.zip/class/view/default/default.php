<!--*************************************** CONTENT BLOCK START *******************************************-->
<div class="container block-content">
    <div class="row">
        <div class="col-lg-4 col-md-4 col-sm-4" >
            bews
        </div>
        <div class="col-lg-8 col-md-8 col-sm-8">
            fjskdfhskdhfksdhfksdjfhksdhfksjdfhksjdfhskjdfhksjfh sdfsdfsdf sfsfsdf<br>
            fjskdfhskdhfksdhfksdjfhksdhfksjdfhksjdfhskjdfhksjfh sdfsdfsdf sfsfsdf<br>
            fjskdfhskdhfksdhfksdjfhksdhfksjdfhksjdfhskjdfhksjfh sdfsdfsdf sfsfsdf<br>
            fjskdfhskdhfksdhfksdjfhksdhfksjdfhksjdfhskjdfhksjfh sdfsdfsdf sfsfsdf<br>
            fjskdfhskdhfksdhfksdjfhksdhfksjdfhksjdfhskjdfhksjfh sdfsdfsdf sfsfsdf<br>
            fjskdfhskdhfksdhfksdjfhksdhfksjdfhksjdfhskjdfhksjfh sdfsdfsdf sfsfsdf<br>
            fjskdfhskdhfksdhfksdjfhksdhfksjdfhksjdfhskjdfhksjfh sdfsdfsdf sfsfsdf<br>
            fjskdfhskdhfksdhfksdjfhksdhfksjdfhksjdfhskjdfhksjfh sdfsdfsdf sfsfsdf<br>
        </div>
    </div>
</div>
<!--*************************************** CONTENT BLOCK END *********************************************-->

