<?php
//$debug = new DebugSystem();
//$debug->debug($params);
//$debug->PhpSetting();
//echo __FILE__;

