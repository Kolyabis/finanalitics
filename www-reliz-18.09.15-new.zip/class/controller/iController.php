<?php
interface iController{}