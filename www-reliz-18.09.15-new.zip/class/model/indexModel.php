<?php
class indexModel{
    protected $_fr;
    protected $_objView;
	protected $_dbQuery;
	protected $_params;
	protected $_lang;
    protected $_getMenu;
    protected $_getSession;
    protected $_modLanguage;


    public function __construct($language){
        $this->_getSession = new SessionSystemSetting();
        $this->_dbQuery = new DbQuery();
        $this->_getMenu = new ComMenu();
        $this->_params = $this->_getMenu->getMenu($this->_dbQuery->select(array("id","page","parent_id","controller","language"), 'mainmenu', array("language"), array("$language"), 2));
        $this->_modLanguage = new mod_language();
        $this->_lang = $this->_modLanguage->langSwitch();
        // TODO: работа с GET ARRAY POST
	    //$this->render();
    }
    public function returnModelParams(){
        return $this->_params;
    }
    public function returnLangParams(){
        return $this->_lang;
    }
/* Возвращает полный результат HTML для вывода на экран */
    //public function render() {
        //$this->_objView = new indexView($this->_post, $this->_params);
        //$this->_objView->GeneretedviewsTpl ();
    //}
}