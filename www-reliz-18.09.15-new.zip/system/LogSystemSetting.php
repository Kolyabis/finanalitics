<?php

/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 12.09.2015
 * Time: 11:54
 */
class LogSystemSetting {

	/**
	 * SessionSystemSetting constructor.
	 */
	public function __construct() {
		return Devoleper::DevViewSetting();
	}

	protected function openFile(){}
	protected function pareseFile(){}
	protected function outputFileData(){}
	protected function closeFile(){}
	protected function saveLogFile(){}


}