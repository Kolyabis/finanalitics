<?php

/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 12.09.2015
 * Time: 11:54
 */
class SessionSystemSetting {
	/**
	 * SessionSystemSetting constructor.
	 */
	public function __construct() {
		session_start();
	}
}