<?php
/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 17.09.2015
 * Time: 22:59
 */
class LanguageSystemSetting {
    public $arrLanguage = array(1 => 'ru', 2 => 'ua', 3 => 'en');
}